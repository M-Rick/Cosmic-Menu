/* extension.js
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */
/* exported Extension */
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

const DEFAULT_SCHEME_NAME = 'default';
const LIGHT_SCHEME_NAME = 'prefer-light';
const DARK_SCHEME_NAME = 'prefer-dark';

export default class LegacyThemeSchemeAutoSwitcher {
    constructor() {
        this._isInitialLoad = true;
    }
    
    executeCommand(command) {
        try {
            let proc = Gio.Subprocess.new(
                command,
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE
            );
            
            proc.communicate_async(null, null, (proc, res) => {
                try {
                    let [, stdout, stderr] = proc.communicate_finish(res);
                    if (proc.get_successful()) {
                        console.log(`Legacy Theme Auto Switcher: Command executed successfully: ${command.join(' ')}`);
                    } else {
                        console.error(`Legacy Theme Auto Switcher: Command failed: ${command.join(' ')}`);
                        if (stderr) {
                            console.error(`Legacy Theme Auto Switcher: Error: ${new TextDecoder().decode(stderr)}`);
                        }
                    }
                } catch (e) {
                    console.error(`Legacy Theme Auto Switcher: Error executing command: ${e.message}`);
                }
            });
        } catch (e) {
            console.error(`Legacy Theme Auto Switcher: Failed to start command: ${e.message}`);
        }
    }

    setXfcePanelDark() {
        console.log('Legacy Theme Auto Switcher: Setting XFCE panel to dark mode');
        
        // Panel sombre : gris foncé semi-transparent
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/panel-1/background-rgba',
            '-s', '0.157000', '-s', '0.157000', '-s', '0.157000', '-s', '0.890000'
        ]);
        
        // Activer le mode sombre XFCE Panel
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/dark-mode',
            '-s', 'true'
        ]);
        
        // Activer le style de fond
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/panel-1/background-style',
            '-s', '1'
        ]);
    }

    setXfcePanelLight() {
        console.log('Legacy Theme Auto Switcher: Setting XFCE panel to light mode');
        
        // Panel clair : fond blanc semi-transparent (0.89 opacity)
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/panel-1/background-rgba',
            '-s', '0.157000', '-s', '0.157000', '-s', '0.157000', '-s', '0.890000'
        ]);
        
        // Désactiver le mode sombre XFCE Panel
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/dark-mode',
            '-s', 'false'
        ]);
        
        // Activer le style de fond
        this.executeCommand([
            'xfconf-query', '-c', 'xfce4-panel', 
            '-p', '/panels/panel-1/background-style',
            '-s', '1'
        ]);
    }

    handleThemeChange = (theme_name) => {
        switch(theme_name)
        {
            case DEFAULT_SCHEME_NAME:
            case LIGHT_SCHEME_NAME:
                if (this.schema.get_string('gtk-theme').endsWith("-dark")) {
                    this.schema.set_string('gtk-theme', this.schema.get_string('gtk-theme').slice(0,-5));
                }
                // Appliquer le thème clair au panel XFCE (seulement si ce n'est pas le chargement initial)
                if (!this._isInitialLoad) {
                    this.setXfcePanelLight();
                }
                break;
            case DARK_SCHEME_NAME:
                if (!this.schema.get_string('gtk-theme').endsWith("-dark")) {
                    this.schema.set_string('gtk-theme', this.schema.get_string('gtk-theme') + "-dark");
                }
                // Appliquer le thème sombre au panel XFCE (seulement si ce n'est pas le chargement initial)
                if (!this._isInitialLoad) {
                    this.setXfcePanelDark();
                }
                break;
            default:
                break;
        }
    }
    
    handleCurrentTheme = () => {
        let value = this.schema.get_string('color-scheme');
        this.handleThemeChange(value);
        // Marquer que le chargement initial est terminé
        this._isInitialLoad = false;
    }
    
    enable() {
        this.schema = Gio.Settings.new('org.gnome.desktop.interface');
        this.id = this.schema.connect('changed::color-scheme', () => {
            this.handleCurrentTheme();
        });
        this.handleCurrentTheme();
    }
    
    disable() {
        if (this.schema) {
            if (this.id) {
                this.schema.disconnect(this.id);
                this.id = null;
            }
            this.schema = null;
        }
        // Réinitialiser le flag pour un éventuel rechargement
        this._isInitialLoad = true;
    }
}
