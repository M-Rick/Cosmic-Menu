"use strict";

import * as Main from "resource:///org/gnome/shell/ui/main.js";
import * as Panel from "resource:///org/gnome/shell/ui/panel.js";
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import St from 'gi://St';
import Gio from 'gi://Gio';
import GObject from 'gi://GObject';
import GLib from 'gi://GLib';

export default class ShortPanelExtension extends Extension {
    enable() {
        this._sleepSignalId = null;
        this._monitorsChangedId = null;
        this._qsChangedId = null;
        this._indicatorSignals = [];
        this._childAddedId = null;
        this._childRemovedId = null;
        this._startupTimeoutId = 0;
        
        // Connect to the system sleep signal
        this._sleepSignalId = Gio.DBus.system.signal_subscribe(
            null,
            'org.freedesktop.login1',
            'org.freedesktop.DBus.Properties',
            'PropertiesChanged',
            '/org/freedesktop/login1',
            'org.freedesktop.login1.Manager',
            (connection, sender, object, interfaceName, signalName, parameters) => {
                const [interfaceChanged, changedProps] = parameters.deep_unpack();
                if (interfaceChanged === 'org.freedesktop.login1.Manager' && changedProps['PrepareForSleep']) {
                    const goingToSleep = changedProps['PrepareForSleep'].deep_unpack();
                    if (goingToSleep) {
                        this._resetPanelWidth();
                    } else {
                        this._adjustPanelWidth();
                    }
                }
            }
        );

        // Connect to the monitor change signal
        this._monitorsChangedId = Main.layoutManager.connect('monitors-changed', () => {
            this._adjustPanelWidth();
        });

        // Watch for items being added to Quick Settings
        const quickSettings = Main.panel.statusArea.quickSettings;
        if (quickSettings) {
            // Connect to the indicators container to monitor child changes
            if (quickSettings._indicators) {
                // Connect existing indicators
                this._connectIndicators();
                
                // Monitor indicator additions and removals
                this._childAddedId = quickSettings._indicators.connect('child-added', () => {
                    this._disconnectIndicators();
                    this._connectIndicators();
                    this._adjustQuickSettingsContainer();
                });
                
                this._childRemovedId = quickSettings._indicators.connect('child-removed', () => {
                    this._disconnectIndicators();
                    this._connectIndicators();
                    this._adjustQuickSettingsContainer();
                });
            }
            
            this._qsChangedId = quickSettings.actor.connect('notify::allocation', () => {
                this._adjustQuickSettingsContainer();
            });
        }

        // Adjust the panel width on startup
        this._adjustPanelWidth();
        
        // Adjust the Quick Settings container on startup
        this._adjustQuickSettingsContainer();

        // Hide the overview at startup
        this._hideOverviewAtStartup();

        // Move all items (except Quick Settings and Date/Time) to the left section of the panel
        this._moveAllToLeftBox();
        
        // Adjust date/time button position
        this._adjustDateMenuPosition();

        // --- NOUVEL AJUSTEMENT D'ESPACEMENT POUR LEFTBOX ---
        if (Main.panel._leftBox) {
            Main.panel._leftBox.spacing = 2; // Définit un espacement de 2 pixels entre les éléments de la leftBox
        }
        // --- FIN NOUVEL AJUSTEMENT ---
    }

    disable() {
        if (this._sleepSignalId) {
            Gio.DBus.system.signal_unsubscribe(this._sleepSignalId);
            this._sleepSignalId = null;
        }

        if (this._monitorsChangedId) {
            Main.layoutManager.disconnect(this._monitorsChangedId);
            this._monitorsChangedId = null;
        }

        const quickSettings = Main.panel.statusArea.quickSettings;
        
        if (this._qsChangedId && quickSettings) {
            quickSettings.actor.disconnect(this._qsChangedId);
            this._qsChangedId = null; 
        }

        if (this._childAddedId && quickSettings && quickSettings._indicators) {
            quickSettings._indicators.disconnect(this._childAddedId);
            this._childAddedId = null;
        }

        if (this._childRemovedId && quickSettings && quickSettings._indicators) {
            quickSettings._indicators.disconnect(this._childRemovedId);
            this._childRemovedId = null;
        }
        
        // Disconnect all indicator signals
        this._disconnectIndicators();

        // Clear the startup timeout if it's still active
        if (this._startupTimeoutId) {
            GLib.source_remove(this._startupTimeoutId);
            this._startupTimeoutId = 0;
        }

        this._resetPanelWidth();
        this._resetPanelItemsPosition(); // Call a reset function for panel items

        // RÉINITIALISATION DES STYLES APPLIQUÉS DYNAMIQUEMENT
        if (quickSettings && quickSettings.actor) {
            quickSettings.actor.style = null; // Réinitialiser le style
            quickSettings.actor.set_position(0, quickSettings.actor.y); // Réinitialiser la position
            if (quickSettings._indicators) {
                quickSettings._indicators.style = null; // Réinitialiser le style des indicateurs
                quickSettings._indicators.set_width(-1); // S'assurer que la largeur est réinitialisée si elle était définie ailleurs
            }
        }
        
        // Reset date/time button position
        this._resetDateMenuPosition();

        // --- RÉINITIALISATION AJUSTEMENT D'ESPACEMENT POUR LEFTBOX ---
        if (Main.panel._leftBox) {
            Main.panel._leftBox.spacing = 0; // Réinitialiser l'espacement à la valeur par défaut (souvent 0)
        }
        // --- FIN RÉINITIALISATION ---
    }

    _connectIndicators() {
        const quickSettings = Main.panel.statusArea.quickSettings;
        if (!quickSettings || !quickSettings._indicators) return;
        
        const indicators = quickSettings._indicators.get_children();
        for (const indicator of indicators) {
            const id = indicator.connect('notify::visible', () => {
                this._adjustQuickSettingsContainer();
            });
            this._indicatorSignals.push({ actor: indicator, id });
        }
    }

    _disconnectIndicators() {
        for (const { actor, id } of this._indicatorSignals) {
            if (actor && actor.disconnect) {
                actor.disconnect(id);
            }
        }
        this._indicatorSignals = [];
    }

    _adjustPanelWidth() {
        const screenWidth = Main.layoutManager.primaryMonitor.width;
        const scaleFactor = St.ThemeContext.get_for_stage(global.stage).scale_factor;
        let panelWidth;

        if (screenWidth <= 1441) {
            // Augmenté de 10px au total
            panelWidth = scaleFactor === 2 ? 535 : 410; // -> 535 ou 410
        } else {
            // Augmenté de 10px au total
            panelWidth = scaleFactor === 2 ? 675 : 430; // -> 685 ou 430
        }

        // Reste à 1px, car Quick Settings est parfait sur la droite
        const rightScreenMargin = 1; 

        const xPosition = screenWidth - panelWidth - rightScreenMargin; 
        const yPosition = -1;

        Main.layoutManager.panelBox.width = panelWidth;
        Main.layoutManager.panelBox.translation_x = xPosition;
        Main.layoutManager.panelBox.translation_y = yPosition;

        this._adjustQuickSettingsContainer(); // Ceci garantit que QS fait 146px de large
    }

    _resetPanelWidth() {
        const screenWidth = Main.layoutManager.primaryMonitor.width;

        Main.layoutManager.panelBox.translation_x = 0;
        Main.layoutManager.panelBox.translation_y = 0;
        Main.layoutManager.panelBox.width = screenWidth;
    }

    _adjustQuickSettingsContainer() {
        const quickSettings = Main.panel.statusArea.quickSettings;
        if (!quickSettings || !quickSettings._indicators || !quickSettings.actor) return;
        
        quickSettings.actor.style = `
            x-align: end; 
            width: 146px; /* Fixe la largeur de Quick Settings à 146px */
        `;

        // Les marges internes sont gérées par le CSS (stylesheet.css)
        quickSettings._indicators.style = `
            x-align: end; /* Assure que le contenu des indicateurs est aligné à droite dans leur boîte */
            -st-box-flow: end; /* Crucial: force l'expansion de droite à gauche */
            spacing: 0px; /* Assure qu'il n'y a pas d'espacement supplémentaire par le conteneur */
        `;
        
        quickSettings.actor.queue_relayout();
    }
    
    _adjustDateMenuPosition() {
        if (Main.panel.dateMenu && Main.panel.dateMenu.container) {
            // Déplacer le bouton date/horloge de 4 pixels à gauche
            Main.panel.dateMenu.container.style = `
                margin-right: 4px;
            `;
            Main.panel.dateMenu.container.queue_relayout();
        }
    }

    _resetDateMenuPosition() {
        if (Main.panel.dateMenu && Main.panel.dateMenu.container) {
            Main.panel.dateMenu.container.style = null; // Réinitialiser le style
            Main.panel.dateMenu.container.set_position(0, Main.panel.dateMenu.container.y); // Réinitialiser la position
        }
    }

    _hideOverviewAtStartup() {
        if (Main.sessionMode.isLocked) return;

        // Use a short delay to ensure the overview is hidden after full initialization
        this._startupTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
            if (Main.overview && Main.overview.visible) {
                Main.overview.hide();
            }
            this._startupTimeoutId = 0;
            return GLib.SOURCE_REMOVE;
        });
    }

    // Fonction pour déplacer tous les éléments souhaités vers la boîte de gauche
    _moveAllToLeftBox() {
        const leftBox = Main.panel._leftBox;
        const rightBox = Main.panel._rightBox; 
        const centerBox = Main.panel._centerBox;

        // Liste des éléments que nous voulons déplacer vers la gauche, identifiés par leurs clés statusArea
        const itemsToMove = [
            'a11y',       // Accessibility
            'appMenu',    // App Indicators (nom plus ancien)
            'appIndicators', // App Indicators (nom plus récent)
            'keyboard',   // Input Source Chooser (Bouton clavier)
            'pop-shell', // Pop Shell Tiling Windows (ID exact trouvé via Looking Glass et confirmé)
        ];

        // L'Activities button est un cas spécial, il n'est pas dans statusArea mais dans la leftBox directement.
        const activitiesButton = Main.panel.statusArea['activities']; 

        // Déplace le bouton activités tout à gauche s'il n'y est pas déjà
        if (activitiesButton && leftBox && activitiesButton.container.get_parent() !== leftBox) {
             const parent = activitiesButton.container.get_parent();
             if (parent) {
                 parent.remove_child(activitiesButton.container);
                 leftBox.insert_child_at_index(activitiesButton.container, 0);
                 log('Moved Activities button to left box.');
             }
        }

        // Déplace les autres éléments spécifiés vers la boîte de gauche
        for (const itemKey of itemsToMove) {
            const item = Main.panel.statusArea[itemKey];
            if (item && item.container) {
                const parent = item.container.get_parent();
                if (parent && parent !== leftBox) { 
                    parent.remove_child(item.container);
                    
                    // --- MODIFICATION POUR POPOS TILING WINDOWS ---
                    // Utilisation de l'identifiant exact "pop-shell"
                    if (itemKey === 'pop-shell') { 
                        // Pour s'assurer qu'il est TOUJOURS le dernier dans la leftBox
                        // On le retire d'abord s'il y est déjà pour le réinsérer à la fin
                        if (item.container.get_parent() === leftBox) {
                            leftBox.remove_child(item.container);
                        }
                        // Insère l'élément à la fin de la liste des enfants de leftBox
                        leftBox.insert_child_at_index(item.container, leftBox.get_children().length);
                        log(`Moved PopOs Tiling Windows (pop-shell) to the end of left box.`);
                    } else {
                        leftBox.add_child(item.container); // Ajoute les autres éléments à la fin de la liste existante
                    }
                    // --- FIN DE LA MODIFICATION ---

                    log(`Moved ${itemKey} to left box.`);
                }
            }
        }
        
        // Cas spécial pour le menu de date, s'il est dans centerBox, assurez-vous que rien d'autre n'y est.
        if (centerBox) {
            const centerChildren = centerBox.get_children();
            for (const child of centerChildren) {
                if (Main.panel.dateMenu && child === Main.panel.dateMenu.container) {
                    continue; // C'est l'horloge, on la laisse.
                }
                if (child.get_parent() === centerBox) { 
                    centerBox.remove_child(child);
                    leftBox.add_child(child);
                    log(`Moved extra item from center box to left box.`);
                }
            }
        }
    }

    _resetPanelItemsPosition() {
        log('Resetting panel item positions (may require extension re-enable).');
    }
}
