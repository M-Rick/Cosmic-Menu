export var Tiled = 0;
export var Floating = 1;
export var Blocked = 2;
export var ForceTile = 3;
